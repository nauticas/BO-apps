<?php $__env->startSection('content'); ?>
        <div class="col-md-12">
            <div class="card">
                <div class="header">
                    <h4 class="title"><?php echo e($title); ?></h4>
                    <p class="category"></p>
                </div>
                <div class="content table-responsive table-full-width">
                    <table class="table table-striped">
                        <thead>
                            <th>No.</th>
                            <th>NIM</th>
                            <th>Nama Mahasiswa</th>
                            <th>Jurusan</th>
                            <th>Semester</th>
                            <th>Program Kelas</th>
                            <th>Status Persetujuan</th>
                            <th>SKS</th>
                            <th>Detail KRS</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mhs): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($mhs->nim); ?></td>
                                <td><?php echo e($mhs->nama_mahasiswa); ?></td>
                                <td><?php echo e($mhs->jurusan); ?></td>
                                <td><?php echo e($mhs->semester); ?></td>
                                <td><?php echo e($mhs->kelas_program); ?></td>
                                <td>
                                <?php if(isset($mhs->status)): ?>
                                    <?php if($mhs->status == 0): ?>
                                        Belum Disetujui
                                    <?php elseif($mhs->status == 1): ?>
                                        Sudah Disetujui
                                    <?php elseif($mhs->status == 2): ?>
                                        Sudah Dinilai
                                    <?php endif; ?>
                                <?php else: ?> 
                                    Belum KRS
                                <?php endif; ?></td>
                                <td><?php echo e($mhs->j_sks); ?></td>
                                <td>
                                <?php if(isset($mhs->krsid) && $mhs->status != 2): ?>
                                <a href="<?php echo e(route('persetujuan.edit',$mhs->krsid)); ?>"" class="btn btn-default">Lihat KRS</a>
                                <?php endif; ?>
                                </td>
                            </tr>
                            </form>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="card">
        <div class="header">
	        <h4 class="title"><?php echo e($title); ?></h4>
	        <p class="category"></p>
	    </div>
	    <div class="content">
	    	<form action="<?php echo e(route('matakuliah.store')); ?>" method="POST">
	    	<?php echo e(csrf_field()); ?>

	    	<div class="row">
		    	<div class="col-md-5">
	                <div class="form-group <?php if($errors->has('kd_mk')): ?> has-error <?php endif; ?>"">
	                    <label>Kode MK</label>
	                    <input type="text" class="form-control border-input" value="<?php echo e(old('kd_mk')); ?>" name="kd_mk">
	                    <span id="helpBlock2" class="help-block"><?php echo e($errors->first('kd_mk')); ?></span>
	                </div>
	            </div>
		    	<div class="col-md-5">
	                <div class="form-group <?php if($errors->has('sks')): ?> has-error <?php endif; ?>"">
	                    <label>SKS</label>
	                    <input type="text" class="form-control border-input" value="<?php echo e(old('sks')); ?>" name="sks">
	                    <span id="helpBlock2" class="help-block"><?php echo e($errors->first('sks')); ?></span>
	                </div>
	            </div>
            </div>
            <div class="row">
		    	<div class="col-md-10">
	                <div class="form-group <?php if($errors->has('nama_mk')): ?> has-error <?php endif; ?>"">
	                    <label>Nama matakuliah</label>
	                    <input type="text" class="form-control border-input" value="<?php echo e(old('nama_mk')); ?>" name="nama_mk">
	                    <span id="helpBlock2" class="help-block"><?php echo e($errors->first('nama_mk')); ?></span>
	                </div>
	            </div>
            </div>
            <div class="row">
		    	<div class="col-md-5">
	                <div class="form-group <?php if($errors->has('semester')): ?> has-error <?php endif; ?>"">
	                    <label>Semester</label>
	                    <input type="text" class="form-control border-input" value="<?php echo e(old('semester')); ?>" name="semester">
	                    <span id="helpBlock2" class="help-block"><?php echo e($errors->first('semester')); ?></span>
	                </div>
	            </div>
	            <div class="col-md-5">
	                <div class="form-group <?php if($errors->has('prasyarat_mk')): ?> has-error <?php endif; ?>"">
	                    <label>Pra Syarat</label>
	                    <select class="form-control border-input" name="prasyarat_mk">
	                    	<option value="" <?php echo e(old('prasyarat_mk') == '' ? 'selected' : ''); ?>>Tidak Ada</option> 
	                    	<?php $__currentLoopData = $prasyarat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kMk => $vMk): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	                    	<option value="<?php echo e($kMk); ?>" <?php echo e(old('prasyarat_mk') == $kMk ? 'selected' : ''); ?>><?php echo e($vMk); ?></option>
	                    	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	                    </select>
	                    <span id="helpBlock2" class="help-block"><?php echo e($errors->first('prasyarat_mk')); ?></span>
	                </div>
	            </div>
            </div>
            <div class="row">
		    	<div class="col-md-5">
	                <div class="form-group <?php if($errors->has('jurusan')): ?> has-error <?php endif; ?>"">
	                    <label>Jurusan</label>
	                    <select class="form-control border-input" name="jurusan">
	                    	<?php $__currentLoopData = $jurusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jur): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	                    	<option value="<?php echo e($jur); ?>" <?php echo e(old('jurusan') == $jur ? 'selected' : ''); ?>><?php echo e($jur); ?></option>
	                    	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	                    </select>
	                    <span id="helpBlock2" class="help-block"><?php echo e($errors->first('jurusan')); ?></span>
	                </div>
	            </div>
	     
            </div>
            <div class="row">
            	<div class="col-md-12">
            		<a href="<?php echo e(route('matakuliah.index')); ?>" class="btn btn-default">Cancel</a>
					<input type="submit" class="btn btn-default">
            	</div>
            </div>
	    	</form>
	    </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
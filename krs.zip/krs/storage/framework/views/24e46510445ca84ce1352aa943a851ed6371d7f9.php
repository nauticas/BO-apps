<?php $__env->startSection('content'); ?>
        <div class="col-md-12">
            <div class="card">
                <div class="header">
                    <h4 class="title"><?php echo e($title); ?></h4>
                    <p class="category"></p>
                </div>
                <div class="content table-responsive table-full-width">
                    <table class="table table-striped">
                        <thead>
                            <th>Kode Tahun Ajaran</th>
                            <th>Keterangan</th>
                            <th>Tgl Kuliah</th>
                            <th>Tgl Awal Perwalian</th>
                            <th>Tgl Akhir Perwalian</th>
                            <th>Status</th>
                            <th>Aksi</th>
                            <th><a href="<?php echo e(route('thnajaran.create')); ?>" class="btn btn-default"><span class="ti-plus"></span> Tambah thnajaran</a></th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $thnajaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ta): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <form action="<?php echo e(route('thnajaran.destroy',$ta->id)); ?>" method="post"  class="form-inline">
                            <tr>
                                <td><?php echo e($ta->kd_tahun); ?></td>
                                <td><?php echo e($ta->keterangan); ?></td>
                                <td><?php echo e($ta->tgl_kuliah); ?></td>
                                <td><?php echo e($ta->tgl_awal_perwalian); ?></td>
                                <td><?php echo e($ta->tgl_akhir_perwalian); ?></td>
                                <td><?php echo e($ta->statuta); ?></td>
                                <td colspan="2">
                                    <a href="<?php echo e(route('thnajaran.edit',$ta->id)); ?>" class="btn btn-info"><i class="ti-pencil-alt"></i></a>
                                    <?php echo e(csrf_field()); ?>

                                    <input type="hidden" name="_method" value="delete" >
                                    <button type="submit" class="btn btn-danger"><i class="ti-close"></i></a>
                                </td>
                            </tr>
                            </form>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($thnajaran->links()); ?>

                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="card">
        <div class="header">
	        <h4 class="title"><?php echo e($title); ?></h4>
	        <p class="category"></p>
	    </div>
	    <div class="content">
	    	<form action="<?php echo e(route('mahasiswa.update',$mahasiswa->id)); ?>" method="POST">
	    	<?php echo e(csrf_field()); ?>

	    	<input type="hidden" name="mhs_id" value="$mahasiswa->id">
	    	<input type="hidden" name="_method" value="PUT">
	    	<div class="row">
		    	<div class="col-md-5">
	                <div class="form-group <?php if($errors->has('nim')): ?> has-error <?php endif; ?>"">
	                    <label>NIM</label>
	                    <input type="text" class="form-control border-input" value="<?php echo e($mahasiswa->nim); ?>" name="nim">
	                    <span id="helpBlock2" class="help-block"><?php echo e($errors->first('nim')); ?></span>
	                </div>
	            </div>
		    	<div class="col-md-5">
	                <div class="form-group <?php if($errors->has('angkatan')): ?> has-error <?php endif; ?>"">
	                    <label>Angkatan</label>
	                    <input type="text" class="form-control border-input" value="<?php echo e($mahasiswa->angkatan); ?>" name="angkatan">
	                    <span id="helpBlock2" class="help-block"><?php echo e($errors->first('angkatan')); ?></span>
	                </div>
	            </div>
            </div>
            <div class="row">
		    	<div class="col-md-10">
	                <div class="form-group <?php if($errors->has('nama_mahasiswa')): ?> has-error <?php endif; ?>"">
	                    <label>Nama mahasiswa</label>
	                    <input type="text" class="form-control border-input" value="<?php echo e($mahasiswa->nama_mahasiswa); ?>" name="nama_mahasiswa">
	                    <span id="helpBlock2" class="help-block"><?php echo e($errors->first('nama_mahasiswa')); ?></span>
	                </div>
	            </div>
            </div>
            <div class="row">
		    	<div class="col-md-5">
	                <div class="form-group <?php if($errors->has('jurusan')): ?> has-error <?php endif; ?>"">
	                    <label>Jurusan</label>
	                    <select class="form-control border-input" name="jurusan">
	                    	<?php $__currentLoopData = $jurusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jur): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	                    	<option value="<?php echo e($jur); ?>" <?php echo e($mahasiswa->jurusan == $jur ? 'selected' : ''); ?>><?php echo e($jur); ?></option>
	                    	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	                    </select>
	                    <span id="helpBlock2" class="help-block"><?php echo e($errors->first('jurusan')); ?></span>
	                </div>
	            </div>
	            <div class="col-md-5">
	                <div class="form-group <?php if($errors->has('kelas_program')): ?> has-error <?php endif; ?>"">
	                    <label>Kelas Program</label>
	                     <select class="form-control border-input" name="kelas_program">
	                    	<?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	                    	<option value="<?php echo e($program); ?>" <?php echo e($mahasiswa->kelas_program == $program ? 'selected' : ''); ?>><?php echo e($program); ?></option>
	                    	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	                    </select>
	                    <span id="helpBlock2" class="help-block"><?php echo e($errors->first('kelas_program')); ?></span>
	                </div>
	            </div>
            </div>
            <div class="row">
		    	<div class="col-md-10">
	                <div class="form-group <?php if($errors->has('dosen_id')): ?> has-error <?php endif; ?>"">
	                    <label>Dosen Wali</label>
	                    <select class="form-control border-input" name="dosen_id">
	                    	<?php $__currentLoopData = $dosen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kdos=>$vdos): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	                    	<option value="<?php echo e($kdos); ?>" <?php echo e($mahasiswa->dosen_id == $kdos ? 'selected' : ''); ?>><?php echo e($vdos); ?></option>
	                    	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	                    </select>
	                    <span id="helpBlock2" class="help-block"><?php echo e($errors->first('dosen_id')); ?></span>
	                </div>
	            </div>
            </div>
            <div class="row">
            	<div class="col-md-12">
            		<a href="<?php echo e(route('mahasiswa.index')); ?>" class="btn btn-default">Cancel</a>
					<input type="submit" class="btn btn-default">
            	</div>
            </div>
	    	</form>
	    </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
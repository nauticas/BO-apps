<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="card">
        <div class="header">
	        <h4 class="title"><?php echo e($title); ?></h4>
	        <p class="category"></p>
	    </div>
	    <div class="content">
	    	<form action="<?php echo e(route('jadwal.store')); ?>" method="POST">
	    	<?php echo e(csrf_field()); ?>

            <div class="row">
		    	<div class="col-md-5">
	                <div class="form-group <?php if($errors->has('mk_id')): ?> has-error <?php endif; ?>">
	                    <label>Matakuliah</label>
	                    <select class="form-control border-input" name="mk_id">
	                    	<?php $__currentLoopData = $matakuliah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mkK => $mkV): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	                    	<option value="<?php echo e($mkK); ?>" <?php echo e(old('mk_id') == $mkK ? 'selected' : ''); ?>><?php echo e($mkV); ?></option>
	                    	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	                    </select>
	                    <span id="helpBlock2" class="help-block"><?php echo e($errors->first('mk_id')); ?></span>
	                </div>
	            </div>
                <div class="col-md-5">
	                <div class="form-group <?php if($errors->has('dosen_id')): ?> has-error <?php endif; ?>">
	                    <label>Dosen</label>
	                    <select class="form-control border-input" name="dosen_id">
	                    	<?php $__currentLoopData = $dosen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosenK => $dosenV): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	                    	<option value="<?php echo e($dosenK); ?>" <?php echo e(old('dosen_id') == $dosenK ? 'selected' : ''); ?>><?php echo e($dosenV); ?></option>
	                    	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	                    </select>
	                    <span id="helpBlock2" class="help-block"><?php echo e($errors->first('dosen_id')); ?></span>
	                </div>
	            </div>
            </div>
	    	<div class="row">
		    	<div class="col-md-5">
	                <div class="form-group <?php if($errors->has('hari')): ?> has-error <?php endif; ?>">
	                    <label>Hari</label>
	                    <select class="form-control border-input" name="hari">
	                    	<?php $__currentLoopData = $hari; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hK => $hV): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	                    	<option value="<?php echo e($hK); ?>" <?php echo e(old('hari') == $hK ? 'selected' : ''); ?>><?php echo e($hV); ?></option>
	                    	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	                    </select>
	                    <span id="helpBlock2" class="help-block"><?php echo e($errors->first('hari')); ?></span>
	                </div>
	            </div>
	            <div class="col-md-2">
	                <div class="form-group <?php if($errors->has('waktu_mulai')): ?> has-error <?php endif; ?>">
	                    <label>Jam Mulai</label>
	                    <input type="text" class="form-control border-input" value="<?php echo e(old('waktu_mulai')); ?>" name="waktu_mulai">
	                    <span id="helpBlock2" class="help-block"><?php echo e($errors->first('waktu_mulai')); ?></span>
	                </div>
	            </div>
	            <div class="col-md-2">
	                <div class="form-group <?php if($errors->has('waktu_selesai')): ?> has-error <?php endif; ?>">
	                    <label>Jam Selesai</label>
	                    <input type="text" class="form-control border-input" value="<?php echo e(old('waktu_selesai')); ?>" name="waktu_selesai">
	                    <span id="helpBlock2" class="help-block"><?php echo e($errors->first('waktu_selesai')); ?></span>
	                </div>
	            </div>
            </div>
            <div class="row">
		    	<div class="col-md-5">
	                <div class="form-group <?php if($errors->has('ruang_id')): ?> has-error <?php endif; ?>">
	                    <label>Ruang</label>
	                    <select class="form-control border-input" name="ruang_id">
	                    	<?php $__currentLoopData = $ruang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ruangK => $ruangV): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	                    	<option value="<?php echo e($ruangK); ?>" <?php echo e(old('ruang_id') == $ruangK ? 'selected' : ''); ?>><?php echo e($ruangV); ?></option>
	                    	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	                    </select>
	                    <span id="helpBlock2" class="help-block"><?php echo e($errors->first('ruang_id')); ?></span>
	                </div>
	            </div>
		    	<div class="col-md-5">
	                <div class="form-group <?php if($errors->has('thnajaran_id')): ?> has-error <?php endif; ?>">
	                    <label>Tahun Ajaran</label>
	                    <select class="form-control border-input" name="thnajaran_id">
	                    	<?php $__currentLoopData = $thn_ajaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thnajaranK => $thnajaranV): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	                    	<option value="<?php echo e($thnajaranK); ?>" <?php echo e(old('thnajaran_id') == $thnajaranK ? 'selected' : ''); ?>><?php echo e($thnajaranV); ?></option>
	                    	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	                    </select>
	                    <span id="helpBlock2" class="help-block"><?php echo e($errors->first('thnajaran_id')); ?></span>
	                </div>
	            </div>
            </div>
            <div class="row">
		    	<div class="col-md-5">
	                <div class="form-group <?php if($errors->has('kapasitas')): ?> has-error <?php endif; ?>">
	                    <label>Kapasitas Kelas</label>
	                    <input type="text" class="form-control border-input" value="<?php echo e(old('kapasitas')); ?>" name="kapasitas">
	                    <span id="helpBlock2" class="help-block"><?php echo e($errors->first('kapasitas')); ?></span>
	                </div>
	            </div>
	            <div class="col-md-2">
	                <div class="form-group <?php if($errors->has('program')): ?> has-error <?php endif; ?>">
	                    <label>Program</label>
	                    <select class="form-control border-input" name="program">
	                    	<?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kK): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	                    	<option value="<?php echo e($kK); ?>" <?php echo e(old('program') == $kK ? 'selected' : ''); ?>><?php echo e($kK); ?></option>
	                    	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	                    </select>
	                    <span id="helpBlock2" class="help-block"><?php echo e($errors->first('program')); ?></span>
	                </div>
	            </div>
	            <div class="col-md-2">
	                <div class="form-group <?php if($errors->has('kelas')): ?> has-error <?php endif; ?>">
	                    <label>Kelas</label>
	                    <input type="text" class="form-control border-input" value="<?php echo e(old('kelas')); ?>" name="kelas">
	                    <span id="helpBlock2" class="help-block"><?php echo e($errors->first('kelas')); ?></span>
	                </div>
	            </div>
            </div>
            <div class="row">
            	<div class="col-md-12">
            		<a href="<?php echo e(route('jadwal.index')); ?>" class="btn btn-default">Cancel</a>
					<input type="submit" class="btn btn-default">
            	</div>
            </div>
	    	</form>
	    </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
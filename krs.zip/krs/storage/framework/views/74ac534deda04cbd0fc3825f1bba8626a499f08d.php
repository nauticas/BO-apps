<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="box">
        <div class="box-header with-border">
            <h4 class="title"><?php echo e($title); ?></h4>
            <p class="category"></p>
        </div>
        
        <div class="content table-responsive table-full-width">
            <table class="table table-striped table-hover ">
                <thead>
                    <th>Kode Dosen</th>
                    <th>NIDN</th>
                    <th>Nama Dosen</th>
                    <th>Aksi</th>
                    <th><a href="<?php echo e(route('dosen.create')); ?>" class="btn btn-success"><span class="fa fa-plus"></span> Tambah Dosen</a></th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $dosen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dos): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <form action="<?php echo e(route('dosen.destroy',$dos->id)); ?>" method="post"  class="form-inline">
                        <tr>
                            <td><?php echo e($dos->kode_dosen); ?></td>
                            <td><?php echo e($dos->nidn); ?></td>
                            <td><?php echo e($dos->nama_dosen); ?></td>
                            <td colspan="2">
                                <a href="<?php echo e(route('dosen.matakuliah',$dos->id)); ?>" class="btn btn-info">MK</a>
                                <a href="<?php echo e(route('dosen.edit',$dos->id)); ?>" class="btn btn-info"><i class="fa fa-pencil"></i></a>
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="_method" value="delete" >
                                <button type="submit" class="btn btn-danger"><i class="fa fa-close"></i></a>
                            </td>
                        </tr>
                    </form>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </tbody>
            </table>
            <?php echo e($dosen->links()); ?>

        </div>
        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>